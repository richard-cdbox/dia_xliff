#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Author: Richard Sitányi (richard@cdbox.sk)
File: dia_xliff.py
Version: 1.0
Date: 10/22/2025
"""

import xml.etree.ElementTree as ET
from xml.dom import minidom
import os
import sys
import shutil
from xml.sax.saxutils import escape, unescape

DIA_NS = "http://www.lysator.liu.se/~alla/dia/"
XLIF_NS = "urn:oasis:names:tc:xliff:document:2.0"

ET.register_namespace("dia", DIA_NS)


def export_dia_to_xliff(dia_path, xliff_path, src_lang="en", target_lang="sk"):
    # Backup of the original file
    backup_path = dia_path + ".bak"
    shutil.copy2(dia_path, backup_path)
    print(f"A backup of the original file has been created: {backup_path}")

    tree = ET.parse(dia_path)
    root = tree.getroot()

    entries = []
    idx = 1

    # Search for all <dia:string> elements in the file
    for string_elem in root.findall(f".//{{{DIA_NS}}}string"):
        if string_elem.text:
            text = string_elem.text.strip()
            # Empty elements or "##" are ignored
            if text == "##" or text == "":
                continue
            # Only texts between # characters are exported
            if text.startswith("#") and text.endswith("#") and len(text) > 2:
                inner_text = text[1:-1]
                text_escaped = escape(inner_text)
                xliff_id = f"string_{idx}"
                string_elem.set("xliff_id", xliff_id)
                entries.append((xliff_id, text_escaped))
                idx += 1

    # Creating an XLIFF file
    xliff = ET.Element("xliff", {"version": "2.2", "xmlns": XLIF_NS})
    file_elem = ET.SubElement(xliff, "file", {
        "id": os.path.basename(dia_path),
        "original": dia_path,
        "srcLang": src_lang,
        "trgLang": target_lang
    })

    for i, (xliff_id, text) in enumerate(entries, start=1):
        unit = ET.SubElement(file_elem, "unit", {"id": xliff_id, "name": str(i)})
        segment = ET.SubElement(unit, "segment")
        source = ET.SubElement(segment, "source")
        source.text = text
        target = ET.SubElement(segment, "target")
        target.text = ""

    # Pretty-print XML
    rough_string = ET.tostring(xliff, encoding="utf-8")
    reparsed = minidom.parseString(rough_string)
    pretty_xml = reparsed.toprettyxml(indent="  ", encoding="utf-8")
    with open(xliff_path, "wb") as f:
        f.write(pretty_xml)

    # The file is saved with the temporary attribute xliff_id in the <dia:string> element
    tree.write(dia_path, encoding="utf-8", xml_declaration=True)
    print(f"The export is complete: {len(entries)} segment(s) → {xliff_path}")


def import_xliff_to_dia(xliff_path, dia_input_path, dia_output_path):
    xlf_tree = ET.parse(xliff_path)
    xlf_root = xlf_tree.getroot()

    # Mapping segments using the xliff_id attribute
    translations = {}
    for unit in xlf_root.findall(f".//{{{XLIF_NS}}}unit"):
        xliff_id = unit.get("id")
        target_elem = unit.find(f".//{{{XLIF_NS}}}target")
        if xliff_id and target_elem is not None and target_elem.text:
            translations[xliff_id] = unescape(target_elem.text.strip())

    dia_tree = ET.parse(dia_input_path)
    dia_root = dia_tree.getroot()

    # Find all <dia:string> elements with the attribute xliff_id
    text_nodes = {}
    for string_elem in dia_root.findall(f".//{{{DIA_NS}}}string[@xliff_id]"):
        xliff_id = string_elem.attrib["xliff_id"]
        text_nodes[xliff_id] = string_elem

    # Inserting translations
    for xliff_id, translation in translations.items():
        node = text_nodes.get(xliff_id)
        if node is not None:
            node.text = f"#{translation}#"
            del node.attrib["xliff_id"]

    dia_tree.write(dia_output_path, encoding="utf-8", xml_declaration=True)
    print(f"The import is complete → {dia_output_path}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage:")
        print("  Export:")
        print("    python dia_xliff.py export <input.dia> <output.xlf> <srcLang> <targetLang>")
        print("  Import:")
        print("    python dia_xliff.py import <input.xlf> <original.dia> <output.dia>")
        sys.exit(1)

    mode = sys.argv[1].lower()

    if mode == "export" and len(sys.argv) == 6:
        _, _, dia_in, xlf_out, src, trg = sys.argv
        export_dia_to_xliff(dia_in, xlf_out, src, trg)
    elif mode == "import" and len(sys.argv) == 5:
        _, _, xlf_in, dia_in, dia_out = sys.argv
        import_xliff_to_dia(xlf_in, dia_in, dia_out)
    else:
        print("Invalid parameters.")
        print("Usage:")
        print("  Export:")
        print("    python dia_xliff.py export <input.dia> <output.xlf> <srcLang> <targetLang>")
        print("  Import:")
        print("    python dia_xliff.py import <input.xlf> <original.dia> <output.dia>")
